//Baytan Shem Ardelee Pioleen M.
//2075 WCSERVER
//Creating a Function

function Display(x) {
    console.log(x)
}

Display(100);