//Baytan Shem Ardelee Pioleen M.
//2075 WCSERVER

var http = require('http');

var server = http.createServer(function(req, res) {

    //path code here
});

server.listen(5100);