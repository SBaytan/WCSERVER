//Baytan Shem Ardelee Pioleen M.
//2075 WCSERVER

var myLogModule = require('./Utility/logs');

myLogModule.info('NodeJS is currently running...')